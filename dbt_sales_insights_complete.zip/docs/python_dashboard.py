import pandas as pd
import pyodbc
import dash
from dash import dcc, html
import plotly.express as px

# Connect to SQL Server
conn = pyodbc.connect(
    "DRIVER={ODBC Driver 17 for SQL Server};"
    "SERVER=localhost;"
    "DATABASE=sales_insights;"
    "UID=your_username;"
    "PWD=your_password"
)

df = pd.read_sql("SELECT * FROM sales_summary", conn)

# Dash App
app = dash.Dash(__name__)

app.layout = html.Div([
    html.H1("Sales Summary Dashboard"),
    dcc.Graph(figure=px.bar(df, x='customer_id', y='total_revenue', title='Revenue by Customer')),
    dcc.Graph(figure=px.scatter(df, x='total_orders', y='total_revenue', title='Orders vs Revenue')),
])

if __name__ == '__main__':
    app.run_server(debug=True)